// Export the main component as the default export
import FileReaderApp from './Explain';

export default FileReaderApp; 