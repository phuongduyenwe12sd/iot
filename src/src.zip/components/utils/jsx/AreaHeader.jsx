import React from 'react';
import { Button } from 'antd';
import { ImportOutlined, ExportOutlined, PlusOutlined } from '@ant-design/icons';

const AreaHeader = ({ title, onImportClick, onExportClick, onAddClick, ImportComponent }) => {
    return (
        <div className="area-header">
            <h2 className="custom-title">{title}</h2>
            <div className="button-level1">
                <Button icon={<ImportOutlined />} onClick={onImportClick}>
                    Nhập File
                </Button>
                <Button icon={<ExportOutlined />} onClick={onExportClick}>
                    Xuất File
                </Button>
                <Button type="primary" icon={<PlusOutlined />} onClick={onAddClick}>
                    Thêm mới
                </Button>
            </div>
            {ImportComponent}
        </div>
    );
};

export default AreaHeader;
