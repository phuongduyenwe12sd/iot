// Export the main component as the default export
import BaoTriTable from './BaoTriTable';

export default BaoTriTable; 